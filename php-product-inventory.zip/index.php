<?php
session_start();

// --- Part 1: Initialize products array with two sample products ---
$products = [
    ['id' => 1, 'name' => 'Wireless Mouse', 'description' => 'Ergonomic wireless mouse', 'price' => 19.99, 'category' => 'Electronics'],
    ['id' => 2, 'name' => 'Notebook', 'description' => '200-page ruled notebook', 'price' => 3.50, 'category' => 'Stationery'],
];

// categories list for dropdown
$categories = ['Electronics', 'Stationery', 'Clothing', 'Home', 'Toys'];

// helper: sanitize input
function clean($s) {
    return trim($s);
}

// initialize
$errors = [];
$submittedData = ['name'=>'', 'description'=>'', 'price'=>'', 'category'=>''];

// --- Part 2: Handle POST submission for adding a product ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // collect and sanitize
    $submittedData['name'] = isset($_POST['name']) ? clean($_POST['name']) : '';
    $submittedData['description'] = isset($_POST['description']) ? clean($_POST['description']) : '';
    $submittedData['price'] = isset($_POST['price']) ? clean($_POST['price']) : '';
    $submittedData['category'] = isset($_POST['category']) ? clean($_POST['category']) : '';

    // validation
    if ($submittedData['name'] === '') {
        $errors['name'] = 'Product name is required.';
    } elseif (mb_strlen($submittedData['name']) < 2) {
        $errors['name'] = 'Product name must be at least 2 characters.';
    }

    if ($submittedData['description'] === '') {
        $errors['description'] = 'Description is required.';
    } elseif (mb_strlen($submittedData['description']) < 5) {
        $errors['description'] = 'Description must be at least 5 characters.';
    }

    if ($submittedData['price'] === '') {
        $errors['price'] = 'Price is required.';
    } elseif (!is_numeric($submittedData['price'])) {
        $errors['price'] = 'Price must be a number.';
    } elseif (floatval($submittedData['price']) <= 0) {
        $errors['price'] = 'Price must be greater than 0.';
    }

    if ($submittedData['category'] === '') {
        $errors['category'] = 'Category is required.';
    } elseif (!in_array($submittedData['category'], $categories)) {
        $errors['category'] = 'Invalid category selected.';
    }

    // If no errors, add product
    if (empty($errors)) {
        // generate unique id (max id + 1)
        $maxId = 0;
        foreach ($products as $p) {
            if ($p['id'] > $maxId) $maxId = $p['id'];
        }
        $newId = $maxId + 1;

        $newProduct = [
            'id' => $newId,
            'name' => $submittedData['name'],
            'description' => $submittedData['description'],
            'price' => floatval($submittedData['price']),
            'category' => $submittedData['category'],
        ];

        // add to products array
        $products[] = $newProduct;

        // set success message via session so it disappears on refresh
        $_SESSION['success'] = 'Product "' . htmlspecialchars($newProduct['name']) . '" added successfully.';

        // clear submitted data so form resets
        $submittedData = ['name'=>'', 'description'=>'', 'price'=>'', 'category'=>''];

        // redirect to the same page to avoid form resubmission and allow flashing message
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>PHP Product Inventory</title>
  <!-- Bootstrap CDN -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body class="bg-light">
  <div class="container py-4">
    <div class="row mb-4">
      <div class="col">
        <h1 class="h3">Product Inventory (PHP Arrays & Forms)</h1>
        <p class="text-muted">A demo that adds products to an in-memory PHP array and shows validation & feedback using Bootstrap.</p>
      </div>
    </div>

    <?php
    // show success message (flash) if set in session
    if (!empty($_SESSION['success'])) {
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">'
            . htmlspecialchars($_SESSION['success']) .
            '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
        unset($_SESSION['success']);
    }
    // show general error alert when there are validation errors
    if (!empty($errors)) {
        echo '<div class="alert alert-danger">Please fix the errors in the form below.</div>';
    }
    ?>

    <div class="row">
      <div class="col-md-6">
        <div class="card mb-4">
          <div class="card-body">
            <h5 class="card-title">Add New Product</h5>
            <form method="post" novalidate>
              <div class="mb-3">
                <label for="name" class="form-label">Product Name</label>
                <input type="text" class="form-control <?php echo isset($errors['name']) ? 'is-invalid' : ''; ?>" id="name" name="name" value="<?php echo htmlspecialchars($submittedData['name']); ?>">
                <?php if (isset($errors['name'])): ?>
                  <div class="invalid-feedback"><?php echo htmlspecialchars($errors['name']); ?></div>
                <?php endif; ?>
              </div>

              <div class="mb-3">
                <label for="description" class="form-label">Description</label>
                <textarea class="form-control <?php echo isset($errors['description']) ? 'is-invalid' : ''; ?>" id="description" name="description" rows="3"><?php echo htmlspecialchars($submittedData['description']); ?></textarea>
                <?php if (isset($errors['description'])): ?>
                  <div class="invalid-feedback"><?php echo htmlspecialchars($errors['description']); ?></div>
                <?php endif; ?>
              </div>

              <div class="mb-3">
                <label for="price" class="form-label">Price (USD)</label>
                <input type="text" class="form-control <?php echo isset($errors['price']) ? 'is-invalid' : ''; ?>" id="price" name="price" value="<?php echo htmlspecialchars($submittedData['price']); ?>">
                <?php if (isset($errors['price'])): ?>
                  <div class="invalid-feedback"><?php echo htmlspecialchars($errors['price']); ?></div>
                <?php endif; ?>
              </div>

              <div class="mb-3">
                <label for="category" class="form-label">Category</label>
                <select class="form-select <?php echo isset($errors['category']) ? 'is-invalid' : ''; ?>" id="category" name="category">
                  <option value="">-- Select category --</option>
                  <?php foreach ($categories as $cat): ?>
                    <option value="<?php echo htmlspecialchars($cat); ?>" <?php echo ($submittedData['category'] === $cat) ? 'selected' : ''; ?>><?php echo htmlspecialchars($cat); ?></option>
                  <?php endforeach; ?>
                </select>
                <?php if (isset($errors['category'])): ?>
                  <div class="invalid-feedback"><?php echo htmlspecialchars($errors['category']); ?></div>
                <?php endif; ?>
              </div>

              <button type="submit" class="btn btn-primary">Add Product</button>
            </form>
          </div>
        </div>
      </div>

      <div class="col-md-6">
        <div class="card mb-4">
          <div class="card-body">
            <h5 class="card-title">Products List</h5>
            <div class="table-responsive">
              <table class="table table-striped table-bordered align-middle">
                <thead class="table-light">
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Category</th>
                    <th class="text-end">Price (USD)</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($products as $p): ?>
                    <tr>
                      <td><?php echo intval($p['id']); ?></td>
                      <td><?php echo htmlspecialchars($p['name']); ?></td>
                      <td><?php echo htmlspecialchars($p['description']); ?></td>
                      <td><?php echo htmlspecialchars($p['category']); ?></td>
                      <td class="text-end"><?php echo number_format(floatval($p['price']), 2); ?></td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
            <p class="text-muted small mb-0">Note: This demo stores products in a PHP array (in-memory). Added products are visible after submission in the same request but are not permanently persisted on the server.</p>
          </div>
        </div>
      </div>
    </div>

    <footer class="text-center text-muted mt-4">
      <small>Prepared by Khalid — update the submission.txt file inside the zip with your GitHub repository URL before submitting.</small>
    </footer>
  </div>
</body>
</html>
